<?php


$pdo=new PDO('mysql:host=localhost;port3306;dbname=info','root');
$pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
      
?>
