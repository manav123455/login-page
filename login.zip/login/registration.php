<?php
include 'connection1.php';
print_r($_POST['name']);
if ( isset($_POST['name']) &&isset($_POST['email']) && isset($_POST['pass']) )
{
  echo "hello";
  $pass=hash('md5',$_POST['pass']);
  $sql="INSERT INTO login (username,email,password) VALUES (:name,:email,:pass)";
  $stmt = $pdo->prepare($sql);
  $stmt->execute( array (':name' =>$_POST['name'] ,
  ':pass'=>"$pass",
  'email'=>$_POST['email'] ));
  echo "registration successfull";
  echo "you will be redirected to login page. if not click <a href='http://localhost/login/loginpage.html'login page</a>";
    sleep(5);
    header('Location:http://localhost/login/login page.html');
}
else{
  echo "registration not successful";
}
